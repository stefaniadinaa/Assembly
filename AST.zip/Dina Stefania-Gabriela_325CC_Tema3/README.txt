Dina Stefania-Gabriela 325CC
Tema IOCLA

In implementare am folosit o varianta recursiva in care la fiecare moment completez nodul curent cu ce imi va furniza strtok aplicat la momentul current pe token.
Pentru despartirea termeniilor si operanziilor am folosit functia strtok.
Functia principala ae urmatorul pseudocod:
    - Aloc memorie pentru nodul curent
    - Pun termenul/operatorul pe campul din data (cu strdup)
    - Daca am un operator inseamna ca trebuie sa avansez pe ramura din stanga si dreapta a nodului curent, apeland din nou functia recursiva.
    - Daca am un termen o sa pun NULL pe stanga si dreapta
    - Returnez nodul construit in eax

Functia iocla_atoi:
    - Memorez semnul numerului, +/-
    - Atata timp cat nu am intalnit terminatorul de sir voi adauga cifra curenta la numarul construit pe parcurs
    - Inmultesc numarul meu cu semnul retinut la inceput (+1/-1)
    - Returnez numarul format in eax