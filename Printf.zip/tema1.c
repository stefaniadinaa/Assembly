#include <unistd.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

static int write_stdout(const char *token, int length)
{
	int rc;
	int bytes_written = 0;

	do {
		rc = write(1, token + bytes_written, length - bytes_written);
		if (rc < 0)
			return rc;

		bytes_written += rc;
	} while (bytes_written < length);

	return bytes_written;
}
static char *convert(unsigned int numar, int baza) 
{ 
	static char caractere[]= "0123456789abcdef";
    //vector static cu toate formele de reprezentare
	static char buffer[50]; 
    //retinem in el de fiecare parte din nr obtinut
	char *p; 
    //necesar pentru returnarea unui char*
    int i, nr = 0;
     
	for(i = 49; i>= 0; i--)
    //retinem toti pasii formarii numarului in buffer
    {   
        if(numar != 0)
	{   nr ++;
    //daca numar este diferit de zero inseamna ca are o cifra
		buffer[i] = caractere[numar%baza];
    //in functie de baza vedem la ce caracter ne oprim 
		numar /= baza; 
	}}
	p = &buffer[49 - nr + 1];
    //adresa unui vector = valoarea din acea casuta
    //in buffer[49] = prima valoare la prima impartire
    //asadar, tot nr se afla la 49 - cifrele nr + 1
	return(p); 
}

int iocla_printf(const char *format, ...)
{	
    int i;
    char a[0];
    char *ascii = (char *)calloc(1, sizeof(char));
    char *symbol = "%";
    const char *p;
    int nr_caractere=0;
    
    va_list args; 
    //dau un nume listei 
	va_start(args, format);
    //incep sa parcurg lista

	while(*format != '\0')
    //cat timp primul argument nu ajunge la final
		{
        if( *format == '%') 
    //cautam formele lui printf %d, %c, %s etc
		{ 
		++format;
    //am gasit % trecem la urmatorul caracter
        switch (*format)
        {
        case '%':
    //daca ne gasim in cazul %% printam doar un % si trecem mai departe

            write_stdout(symbol,1);
            nr_caractere++;
    //nu uitam sa incrementam cand afisem un caracter 
            break;

        case 'u':
            i = va_arg(args, unsigned int);
    //primul arument din lista
            write_stdout(convert(i,10),strlen(convert(i,10)));
    //afisam dar nu inainte de-al converti la baza si transforma in char*
            nr_caractere+=strlen(convert(i,10));
            break;

        case 's':
            p = va_arg(args, const char*);
    //primul argument const char* din lista
            i = strlen(p);
    //lungimea acestuia
            write_stdout(p,i);
    //afisam pur si simplu fara a converti
            nr_caractere+=i;
    //incrementam cu lungimea sirului 
            break;

        case 'd':
            i = va_arg(args, int);
            char *result = (char *)calloc(1000, sizeof(char));
    //retin in acest vector prin concatenare, numarul negativ/pozitiv
            if(i<0)
            {
                i = -i;
    //il facem pozitiv pentru functia convert
               strcat(result, "-");
    //adaug in result semnul minus
            }
            strcat(result, convert(i, 10));
    //adaug si nr convertit
            write_stdout(result,strlen(result));
            nr_caractere+=strlen(result);
    //incrementez cu lungimea dupa formarea lui result
            free(result);
    //eliberez memoria, sa nu o incarcam degeaba :) 
            break;

        case 'x':
            i = va_arg(args, unsigned int);
            write_stdout(convert(i, 16),strlen(convert(i,16)));
    //convertesc la baza hexazecimala, pe 16 biti 
            nr_caractere+=strlen(convert(i,16));
            break;

        case 'c':
            i = va_arg(args, int);
            if(i != 0)
    //vedem daca exista inca un argument int in lista
            a[0] = (char)i;
    //il convertesc la char si il salvez intr-un mini vector cu un singur element
            ascii = strdup(a);
    //elimin spatii albe si salvez intr-un vector char*
            write_stdout(ascii,1);
    //printez reprezentarea ascii care are lungimea 1 mereu
            free(ascii);
    //eliberez memoria 
            nr_caractere++;
    //incrementez lungimea cu 1 mereu
            break;

        default:
            break;
    //niciun caz -> iesim
        }
    }
    else{
        const char *c=format;
    //nu se incadreaza atunci copiem respectivul caracter
    //din pozitia in care ne aflam 
        write_stdout(c,1);
        nr_caractere++;
        }
    ++format;
    //trecem mai departe prin string-ul format
}
va_end(args);
    //inchidem lista
return nr_caractere;
    
}



